


# Documentation and Style

TODO
look at [Google guide for now](https://google.github.io/styleguide/cppguide.html)

## Documentation Style



### Function
```c++
/**
	Computes Foo from Bar. Foo is calculated by ...
	@param b a simple Bar object
	@return The Foo object derived from Bar
*/
Foo foo(Bar b);
```