
// std
#include <iostream>
#include <string>
#include <chrono>
#include <filesystem>

// glm
#include <glm/gtc/constants.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

// project
#include "application.hpp"
#include "cgra/cgra_gui.hpp"
#include "cgra/cgra_shader.hpp"

using namespace std;
using namespace cgra;
using namespace glm;

Application::Application(GLFWwindow *window) : m_window(window) {
	// build the shader
	shader_builder color_sb;
	color_sb.set_shader(GL_VERTEX_SHADER, CGRA_SRCDIR + std::string("//res//shaders//default_vert.glsl"));
	color_sb.set_shader(GL_FRAGMENT_SHADER, CGRA_SRCDIR + std::string("//res//shaders//default_frag.glsl"));
	m_shader = color_sb.build();

	// build the mesh for the triangle
	m_model.setup();
}

void Application::render() {
	// retrieve the window hieght
	int width, height;
	glfwGetFramebufferSize(m_window, &width, &height); 

	m_windowsize = vec2(width, height); // update window size
	glViewport(0, 0, width, height); // set the viewport to draw to the entire window

	// clear the back-buffer
	glClearColor(0.3f, 0.3f, 0.4f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); 

	// enable flags for normal/forward rendering
	glEnable(GL_DEPTH_TEST); 
	glDepthFunc(GL_LESS);

	// calculate the projection and view matrix
	mat4 proj = perspective(1.f, float(width) / height, 0.1f, 1000.f);
	mat4 view = translate(mat4(1), vec3(0, -5, -20));

	// set shader and upload variables
	glUseProgram(m_shader);
	glUniformMatrix4fv(glGetUniformLocation(m_shader, "uProjectionMatrix"), 1, false, value_ptr(proj));
	glUniformMatrix4fv(glGetUniformLocation(m_shader, "uModelViewMatrix"), 1, false, value_ptr(view));

	// draw the obj
    draw();
}

void Application::renderGUI() {
	// setup window
	ImGui::SetNextWindowPos(ImVec2(5, 5), ImGuiSetCond_Once);
	ImGui::SetNextWindowSize(ImVec2(500, 175), ImGuiSetCond_Once);
	ImGui::Begin("Mesh loader", 0);

	// Loading buttons
	static char filename[512] = "teapot.obj";
	ImGui::InputText("", filename, 512);
	ImGui::SameLine();
	if (ImGui::Button("Load")) {
        char path[512] = "..\\..\\..\\work\\res\\assets\\";
        strcat(path, filename);
		loadOBJ(path);
    }
	ImGui::SameLine();
	if (ImGui::Button("Print")) {
        printMeshData();
	}
	ImGui::SameLine();
	if (ImGui::Button("Unload")) {
        destroy();
        printf("Unloaded object\n");
	}

    // change colour
    ImGui::ColorEditMode(ImGuiColorEditMode_RGB); 
    if (ImGui::ColorEdit3("Set Color", (float*) &colour)) {
        glm::vec3 colourVec = colour;
        setColour(colourVec);
    }

    // change light position
    ImGui::NewLine();
    float lightRange = 50.0f;
    if (ImGui::SliderFloat("Light X", (float *) &lightPos.x, -lightRange, lightRange, "%.3f"))
        setLightPosition(lightPos);
    if (ImGui::SliderFloat("Light Y", (float*) &lightPos.y, -lightRange, lightRange, "%.3f"))
        setLightPosition(lightPos);
    if (ImGui::SliderFloat("Light Z", (float*) &lightPos.z, -lightRange, lightRange, "%.3f")) 
        setLightPosition(lightPos);
	// finish creating window
	ImGui::End();
}

bool Application::loadOBJ(const char* path) {
    destroy();
    printf("Loading OBJ file: %s\n", path);

    std::vector<unsigned int> vertexIndices, normalIndices;
    std::vector<glm::vec3> temp_vertices;
    std::vector<glm::vec3> temp_normals;

    FILE* file = fopen(path, "r");
    if (file == NULL) {
        printf("File not found.\n");
        return false;
    }

    while (true) {
        char lineHeader[128];
        // read the first word of the line
        int res = fscanf(file, "%s", lineHeader);
        if (res == EOF)
            break; // exit on eof

        // else : parse line header
        if (strcmp(lineHeader, "v") == 0) {
            glm::vec3 vertex;
            fscanf(file, "%f %f %f\n", &vertex.x, &vertex.y, &vertex.z);
            temp_vertices.push_back(vertex);
        }
        else if (strcmp(lineHeader, "vn") == 0) {
            glm::vec3 normal;
            fscanf(file, "%f %f %f\n", &normal.x, &normal.y, &normal.z);
            temp_normals.push_back(normal);
        }
        else if (strcmp(lineHeader, "f") == 0) {
            std::string vertex1, vertex2, vertex3;
            unsigned int vertexIndex[3], uvIndex[3], normalIndex[3];
            int matches = fscanf(file, "%d/%d/%d %d/%d/%d %d/%d/%d\n", &vertexIndex[0], &uvIndex[0], &normalIndex[0], &vertexIndex[1], &uvIndex[1], &normalIndex[1], &vertexIndex[2], &uvIndex[2], &normalIndex[2]);
            if (matches != 9) {
                printf("File did not parse correctly.\n");
                fclose(file);
                return false;
            }
            vertexIndices.push_back(vertexIndex[0]);
            vertexIndices.push_back(vertexIndex[1]);
            vertexIndices.push_back(vertexIndex[2]);
            normalIndices.push_back(normalIndex[0]);
            normalIndices.push_back(normalIndex[1]);
            normalIndices.push_back(normalIndex[2]);
        }
    }

    // For each vertex of each triangle
    for (unsigned int i = 0; i < vertexIndices.size(); i++) {
        // Get the indices of its attributes
        unsigned int vertexIndex = vertexIndices[i];
        unsigned int normalIndex = normalIndices[i];

        // Get the attributes using index
        glm::vec3 vertex = temp_vertices[vertexIndex - 1];
        glm::vec3 normal = temp_normals[normalIndex - 1];

        // Put the attributes in buffers
        m_positions.push_back(vertex);
        m_normals.push_back(normal);
        m_indices.push_back(i);
    }
    printf("Finished loading\n");
    fclose(file);
    setColour(colour);
    setLightPosition(lightPos);
    build();
    return true;
}

void Application::setColour(glm::vec3 newColour) {
    glUseProgram(m_shader);
    GLuint location = glGetUniformLocation(m_shader, "surfaceColour");
    glUniform3f(location, colour.x, colour.y, colour.z);
}

void Application::setLightPosition(glm::vec3 newPos) {
    glUseProgram(m_shader);
    GLuint location = glGetUniformLocation(m_shader, "lightPosition");
    glUniform3f(location, newPos.x, newPos.y, newPos.z);
}

void Application::build() {
    if (m_vao == 0) {
        // generate buffers
        glGenVertexArrays(1, &m_vao); // VAO stores information about how the buffers are set up
        glGenBuffers(1, &m_vbo_pos); // VBO stores the vertex data
        glGenBuffers(1, &m_vbo_norm);
        glGenBuffers(1, &m_ibo); // IBO stores the indices that make up primitives

        // VAO
        //
        glBindVertexArray(m_vao);

        // VBO
        //
        // upload Positions to this buffer
        glBindBuffer(GL_ARRAY_BUFFER, m_vbo_pos);
        glBufferData(GL_ARRAY_BUFFER, sizeof(glm::vec3) * m_positions.size(), m_positions.data(), GL_STATIC_DRAW);
        // this buffer will use location=0 when we use our VAO
        glEnableVertexAttribArray(0);
        // tell opengl how to treat data in location=0 - the data is treated in lots of 3 (3 floats = vec3)
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, nullptr);

        // do the same thing for Normals but bind it to location=1
        glBindBuffer(GL_ARRAY_BUFFER, m_vbo_norm);
        glBufferData(GL_ARRAY_BUFFER, sizeof(glm::vec3) * m_normals.size(), m_normals.data(), GL_STATIC_DRAW);
        glEnableVertexAttribArray(1);
        glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 0, nullptr);


        // IBO
        //
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m_ibo);
        // upload the indices for drawing primitives
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(unsigned int) * m_indices.size(), m_indices.data(), GL_STATIC_DRAW);

        // clean up by binding VAO 0 (good practice)
        glBindVertexArray(0);
    }
}

void Application::draw() {
    if (m_vao == 0) return;
    // bind our VAO which sets up all our buffers and data for us
    glBindVertexArray(m_vao);
    // tell opengl to draw our VAO using the draw mode and how many verticies to render
    glDrawElements(GL_TRIANGLES, m_indices.size(), GL_UNSIGNED_INT, 0);
}

void Application::destroy() {
    // delete the data buffers
    glDeleteVertexArrays(1, &m_vao);
    glDeleteBuffers(1, &m_vbo_pos);
    glDeleteBuffers(1, &m_vbo_norm);
    glDeleteBuffers(1, &m_ibo);
    m_positions.clear();
    m_normals.clear();
    m_indices.clear();
    m_vao = 0;
}

void Application::printMeshData() {
    printf("\nPRINTING MESH DATA------------------------\n");
    printf("Vertices:\n");
    for (int i = 0; i < m_positions.size(); i++) {
        glm::vec3 v = m_positions[i];
        printf("v %d: %f %f %f\n", i, v.x, v.y, v.z);
    }
    printf("Normals:\n");
    for (int i = 0; i < m_normals.size(); i++) {
        glm::vec3 v = m_normals[i];
        printf("vn %d: %f %f %f\n", i, v.x, v.y, v.z);
    }
    printf("------------------------------------------\n");
}

/////////////////////////////////////////////////////////////////////////////////

void Application::cursorPosCallback(double xpos, double ypos) {
	(void)xpos, ypos; // currently un-used
}

void Application::mouseButtonCallback(int button, int action, int mods) {
	(void)button, action, mods; // currently un-used
}

void Application::scrollCallback(double xoffset, double yoffset) {
	(void)xoffset, yoffset; // currently un-used
}

void Application::keyCallback(int key, int scancode, int action, int mods) {
	(void)key, (void)scancode, (void)action, (void)mods; // currently un-used
}

void Application::charCallback(unsigned int c) {
	(void)c; // currently un-used
}