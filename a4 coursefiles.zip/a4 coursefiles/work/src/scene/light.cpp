
// glm
#include <glm/gtc/constants.hpp>

// project
#include "light.hpp"
#include "scene_object.hpp"

using namespace glm;

bool DirectionalLight::occluded(Scene *scene, const vec3 &point) const {
	//-------------------------------------------------------------
	// [Assignment 4] :
	// Determine whether the given point is being occluded from
	// this directional light by an object in the scene.
	// Remember that directional lights are "infinitely" far away
	// so any object in the way would cause an occlusion.
	//-------------------------------------------------------------
	Ray shadowRay = Ray(point, -this->m_direction);
	for (int i = 0; i < scene->objects().size(); i++) {
		RayIntersection intersect = scene->objects().at(i)->intersect(shadowRay);
		if (intersect.m_valid) {
			if (scene->objects().at(i)->intersect(shadowRay).m_distance > epsilon)
				return true; // intersection with shadow ray: this point is in shadow
		}
	}

	return false;
}

vec3 DirectionalLight::incidentDirection(const vec3 &) const {
	return m_direction;
}

vec3 DirectionalLight::irradiance(const vec3 &) const {
	return m_irradiance;
}

bool PointLight::occluded(Scene *scene, const vec3 &point) const {
	//-------------------------------------------------------------
	// [Assignment 4] :
	// Determine whether the given point is being occluded from
	// this directional light by an object in the scene.
	// Remember that point lights are somewhere in the scene and
	// an occulsion has to occur somewhere between the light and 
	// the given point.
	//-------------------------------------------------------------
	vec3 dist = this->m_position - point;
	float len = length(dist);
	if (len == 0) return false;
	Ray shadowRay = Ray(point, normalize(dist));
	for (int i = 0; i < scene->objects().size(); i++) {
		// intersection with shadow ray: this point is in shadow
		RayIntersection intersect = scene->objects().at(i)->intersect(shadowRay);
		if (intersect.m_valid && intersect.m_distance > epsilon && intersect.m_distance <= len) {
			return true;
		}
		
	}
	return false;
}

vec3 PointLight::incidentDirection(const vec3 &point) const {
	//-------------------------------------------------------------
	// [Assignment 4] :
	// Return the direction of the incoming light (light to point)
	//-------------------------------------------------------------

	return normalize(vec3(point - this->m_position));
}


vec3 PointLight::irradiance(const vec3 &point) const {
	//-------------------------------------------------------------
	// [Assignment 4] :
	// Return the total irradiance on the given point.
	// This requires you to convert the flux of the light into
	// irradiance by dividing it by the surface of the sphere
	// it illuminates. Remember that the surface area increases
	// as the sphere gets bigger, ie. the point is further away.
	//-------------------------------------------------------------

	float r = length(vec3(point - this->m_position));
	if (r == 0) return this->m_flux;
	return this->m_flux * (float)(1 / (4 * 3.1415926535897932384626433 * r * r));
}