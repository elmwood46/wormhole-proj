// glm
#include <glm/gtc/constants.hpp>
#include <glm/gtc/random.hpp>

// std
#include <random>

// project
#include "scene.hpp"
#include "shape.hpp"
#include "light.hpp"
#include "material.hpp"
#include "path_tracer.hpp"

using namespace std;
using namespace glm;

vec3 SimplePathTracer::sampleRay(const Ray &ray, int) {
	// intersect ray with the scene
	RayIntersection intersect = m_scene->intersect(ray);

	// if ray hit something
	if (intersect.m_valid) {

		// simple grey shape shading
		float f = abs(dot(-ray.direction, intersect.m_normal));
		vec3 grey(0.5, 0.5, 0.5);
		return mix(grey / 2.0f, grey, f);
	}

	// no intersection - return background color
	return { 0.3f, 0.3f, 0.4f };
}


vec3 CorePathTracer::sampleRay(const Ray &ray, int) {
	//-------------------------------------------------------------
	// [Assignment 4] :
	// Implement a PathTracer that calculates the ambient, diffuse
	// and specular, for the given ray in the scene, using the 
	// Phong lighting model. Give special consideration to objects
	// that occluded from direct lighting (shadow rays). You do
	// not need to use the depth argument for this implementation.
	//-------------------------------------------------------------
	RayIntersection intersect = m_scene->intersect(ray);

		// if ray hit something
	if (intersect.m_valid) {
		// do shading
		vec3 col = vec3(0);
		// get base diffuse and specular
		vec3 diffuse = intersect.m_material->diffuse();
		vec3 specular = intersect.m_material->specular();

		for (int i = 0; i < m_scene->lights().size(); i++) {
			// get light
			std::shared_ptr<Light> light = m_scene->lights().at(i);

			// increment colour by base diffuse of material
			col += diffuse * light->ambience();

			if (!light->occluded(m_scene, intersect.m_position)) {
				// calculate irradiance and incident direction
				vec3 irrad = light->irradiance(intersect.m_position);
				vec3 incDir = normalize(light->incidentDirection(intersect.m_position));

				//// calculate diffuse reflection
				float angle = dot(-incDir, intersect.m_normal);
				vec3 diffuse_reflect = (angle > 0) ? diffuse * irrad * angle : vec3(0);

				//calculate specular reflection
				vec3 spec_reflect = reflect(incDir, intersect.m_normal);
				angle = dot(-ray.direction, spec_reflect);
				if (angle > 0) {
					spec_reflect = irrad * pow(angle, intersect.m_material->shininess()) * specular;
				}
				else {
					spec_reflect = vec3(0);
				}
				
				// increment colour
				col += (diffuse_reflect + spec_reflect);
			}
		}

		return col;
	}
	
	// no intersection - return background color
	return { 0.3f, 0.3f, 0.4f };
}



vec3 CompletionPathTracer::sampleRay(const Ray &ray, int depth) {
	//-------------------------------------------------------------
	// [Assignment 4] :
	// Using the same requirements for the CorePathTracer add in 
	// a recursive element to calculate perfect specular reflection.
	// That is compute the reflection ray off your intersection and
	// sample a ray in that direction, using the result to additionally
	// light your object. To make this more realistic you may weight
	// the incoming light by the (1 - (1/shininess)).
	//-------------------------------------------------------------

	RayIntersection intersect = m_scene->intersect(ray);

	// if ray hit something
	if (intersect.m_valid) {
		// do shading
		vec3 col = vec3(0);
		// get base diffuse and specular
		vec3 diffuse = intersect.m_material->diffuse();
		vec3 specular = intersect.m_material->specular();

		for (int i = 0; i < m_scene->lights().size(); i++) {
			// get light
			std::shared_ptr<Light> light = m_scene->lights().at(i);

			// increment colour by base diffuse of material
			col += diffuse * light->ambience();

			if (!light->occluded(m_scene, intersect.m_position)) {
				// calculate irradiance and incident direction
				vec3 irrad = light->irradiance(intersect.m_position);
				vec3 incDir = normalize(light->incidentDirection(intersect.m_position));

				//// calculate diffuse reflection
				float angle = dot(-incDir, intersect.m_normal);
				vec3 diffuse_reflect = (angle > 0) ? diffuse * irrad * angle : vec3(0);

				//calculate specular reflection
				vec3 spec_reflect = reflect(incDir, intersect.m_normal);
				angle = dot(-ray.direction, spec_reflect);
				if (angle > 0) {
					spec_reflect = irrad * pow(angle, intersect.m_material->shininess()) * specular;
				}
				else {
					spec_reflect = vec3(0);
				}

				// increment colour
				col += (diffuse_reflect + spec_reflect);
			}
		}

		// calculate reflection
		if (depth > 0) {
			vec3 reflectDir = reflect(ray.direction, intersect.m_normal);

			Ray reflectedRay = Ray(intersect.m_position, reflectDir);
			float reflectWeight = glm::max((1 - 1 / intersect.m_material->shininess()), 0.001f);
			col += this->sampleRay(reflectedRay, depth - 1) * reflectWeight;
		}

		return col;
	}

	// no intersection - return background color
	return { 0.3f, 0.3f, 0.4f };
}

vec3 ChallengePathTracer::sampleRay(const Ray &ray, int depth) {
	//-------------------------------------------------------------
	// [Assignment 4] :
	// Implement a PathTracer that calculates the diffuse and 
	// specular, for the given ray in the scene, using the 
	// Phong lighting model. Give special consideration to objects
	// that occluded from direct lighting (shadow rays).
	// Implement support for textured materials (using a texture
	// for the diffuse portion of the material).
	//
	// EXTRA FOR EXPERTS :
	// Additionally implement indirect diffuse and specular instead
	// of using the ambient lighting term.
	// The diffuse is sampled from the surface hemisphere and the
	// specular is sampled from a cone of the phong lobe (which
	// gives a glossy look). For best results you need to normalize
	// the lighting (see http://www.thetenthplanet.de/archives/255)
	//-------------------------------------------------------------

	RayIntersection intersect = m_scene->intersect(ray);

	// if ray hit something
	if (intersect.m_valid) {
		// do shading
		vec3 col = vec3(0);
		// get base diffuse and specular
		vec3 diffuse;
		if (intersect.m_material->textured()) {
			diffuse = intersect.m_material->textureSample(intersect.m_uv_coord);
		} else {
			diffuse = intersect.m_material->diffuse();
		}
		vec3 specular = intersect.m_material->specular();

		for (int i = 0; i < m_scene->lights().size(); i++) {
			// get light
			std::shared_ptr<Light> light = m_scene->lights().at(i);

			// increment colour by base diffuse of material
			col += diffuse * light->ambience();

			if (!light->occluded(m_scene, intersect.m_position)) {
				// calculate irradiance and incident direction
				vec3 irrad = light->irradiance(intersect.m_position);
				vec3 incDir = normalize(light->incidentDirection(intersect.m_position));

				//// calculate diffuse reflection
				float angle = dot(-incDir, intersect.m_normal);
				vec3 diffuse_reflect = (angle > 0) ? diffuse * irrad * angle : vec3(0);

				//calculate specular reflection
				vec3 spec_reflect = reflect(incDir, intersect.m_normal);
				angle = dot(-ray.direction, spec_reflect);
				if (angle > 0) {
					spec_reflect = irrad * pow(angle, intersect.m_material->shininess()) * specular;
				}
				else {
					spec_reflect = vec3(0);
				}

				// increment colour
				col += (diffuse_reflect + spec_reflect);
			}
		}

		// calculate reflection
		if (depth > 0) {
			vec3 reflectDir = reflect(ray.direction, intersect.m_normal);

			Ray reflectedRay = Ray(intersect.m_position, reflectDir);
			float reflectWeight = glm::max((1 - 1 / intersect.m_material->shininess()), 0.001f);
			col += this->sampleRay(reflectedRay, depth - 1) * reflectWeight;
		}

		return col;
	}

	// no intersection - return background color
	return { 0.3f, 0.3f, 0.4f };
}